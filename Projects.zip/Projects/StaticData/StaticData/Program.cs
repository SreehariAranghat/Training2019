﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticData
{
    class Program
    {
        static void Main(string[] args)
        {
            List<User> users = new List<User>();
            users.Add(new User { FirstName = "Sree"
                                , UserName = "Sree", Password = "12345" });

            users.Add(new User
            {
                FirstName = "Bill",
                UserName = "BillG",
                Password = "124"
            });


            UserManager deskTopUserManager = new UserManager();
            UserManager webAppUserManager  = new UserManager();

            deskTopUserManager.userList.AddRange(users);
            webAppUserManager.userList.AddRange(users);

            UserManager.Log("Sree", "Trying to authenticate");

            deskTopUserManager.Autheticate("Sree", "12345");
            deskTopUserManager.Autheticate("BillG", "23452354");

            UserManager.Log("System", $"Total successful login" +
                $" as of {DateTime.Now} = {UserManager.TotalAuthentication}");

            webAppUserManager.Autheticate("BillG", "124");


        }
    }
}
