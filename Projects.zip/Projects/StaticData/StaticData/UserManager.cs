﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticData
{
    public class UserManager
    {
        public List<User> userList = new List<User>();
        public static int TotalAuthentication      = 0;
        public static int TotalFailedAuthetication = 0;

        public static List<string> userActivityLog = new List<string>();

        public bool Autheticate(string username,string password)
        {
            foreach(User u in userList)
            {
                if(u.UserName == username && u.Password == password)
                {
                    TotalAuthentication += 1;
                    return true;
                }
            }

            TotalFailedAuthetication += 1;
            return false;
        }

        public static void Log(string userName,string userActivity)
        {
            userActivityLog.Add($"Log : User/{userName}" +
                $",Date : {DateTime.Now}, Message : {userActivity}");
        }
    }
}
