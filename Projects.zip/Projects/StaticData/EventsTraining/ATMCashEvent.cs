﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsTraining
{
    public enum TransactionType
    {
        WithDrawal
        ,Deposit
    }

    public class ATMCashEvent : EventArgs
    {
        public int Amount { get; set; }
        public TransactionType TransactionType { get; set; }
        public int CustomerId { get; set; }
        public bool IsTransactionSuccesful { get; set; }
    }
}
