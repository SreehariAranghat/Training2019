﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            ATM atm = new ATM { AvailableMoney = 10000 };
            atm.CashChanged += SentSmsHandler;
            atm.CashChanged += UpdateTransLogHandler;

            atm.WithDrawMoney(1001,5000);
            atm.WithDrawMoney(2003, 30000);

            atm.DepositMoney(3456, 2000);
            atm.WithDrawMoney(356, 7999);
        }

        private static void UpdateTransLogHandler(object sender, ATMCashEvent e)
        {
            File.WriteAllText(@"c:\translog\log.txt",
                $"ATM EVENT [{DateTime.Now}] : {e.TransactionType.ToString()}" +
                $" | Customer : {e.CustomerId} | Status : {e.IsTransactionSuccesful} " +
                $" | Amount : {e.Amount}"); 
        }

        private static void SentSmsHandler(object sender, ATMCashEvent e)
        {
            if(e.IsTransactionSuccesful)
            {
                Console.ForegroundColor = ConsoleColor.Green;

                if(e.TransactionType == TransactionType.Deposit)
                     Console.WriteLine($"Dear {e.CustomerId} a deposit of {e.Amount} has happened");
                else
                    Console.WriteLine($"Dear {e.CustomerId} a withdrawal of {e.Amount} has happened");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Dear {e.CustomerId} a transaction of {e.Amount} has Failed");
            }

            Console.ForegroundColor = ConsoleColor.White;
             
        }
    }
}
