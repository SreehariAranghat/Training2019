﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsTraining
{
    public class ATM
    {
        public int AvailableMoney { get; set; }
        public List<string> TrasactionLogs = new List<string>();

        public event EventHandler<ATMCashEvent> CashChanged;

        public void DepositMoney(int customerId,int amount)
        {
            AvailableMoney += amount;

            ATMCashEvent cashEvent = new ATMCashEvent
            {
                 Amount = amount
                ,CustomerId = customerId
                ,TransactionType = TransactionType.Deposit
                ,IsTransactionSuccesful = true
            };

            CashChanged(this, cashEvent);

        }

        public int WithDrawMoney(int customerId,int amount)
        {
            ATMCashEvent cashEvent    = new ATMCashEvent();
            cashEvent.CustomerId      = customerId;
            cashEvent.Amount          = amount;
            cashEvent.TransactionType = TransactionType.WithDrawal;

            if(amount <= AvailableMoney)
            {
                cashEvent.IsTransactionSuccesful = true;    
            }
            else
            {
                cashEvent.IsTransactionSuccesful = false;
            }

            CashChanged(this, cashEvent);

            return cashEvent.IsTransactionSuccesful ? amount : 0;
        }
    }
}
