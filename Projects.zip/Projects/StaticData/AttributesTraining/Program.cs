﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AttributesTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeManager.PromoteEmoloyee();

            GenericIdentity identity = new GenericIdentity("Sree");
            GenericPrincipal genericPrincipal = new GenericPrincipal(identity
                                        , new string[] { "Admin","HR" });

            Thread.CurrentPrincipal = genericPrincipal;

            EmployeeManager.HireEmployee();

            Type type = typeof(EmployeeManager);
           
            foreach(Attribute a in type.GetCustomAttributes(true))
            {
                LogAttribute l = (LogAttribute)a;
                Console.WriteLine($"Class Name : {l.ClassName}, Log Date : {l.LogDate}" +
                    $" , Message : {l.Message}");
            }

        }
    }
}
