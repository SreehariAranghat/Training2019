﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace AttributesTraining
{
    [Log("EmployeeManager",LogDate = "12/11/2019",Message = "File Created")]
    public class EmployeeManager
    {
        [PrincipalPermission(SecurityAction.Demand,Role = "HR")]
        public static void HireEmployee()
        {
            Console.WriteLine("Hiring Employee X");
        }

        public static void PromoteEmoloyee()
        {
            Console.WriteLine("Promote Employee X");
        }
    }
}
