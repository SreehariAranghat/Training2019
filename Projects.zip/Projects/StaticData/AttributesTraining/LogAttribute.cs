﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesTraining
{
    [AttributeUsage(AttributeTargets.Class)]
    public class LogAttribute : Attribute
    {
        public string LogDate { get; set; }
        public string Message { get; set; }

        
        public string ClassName { get; private set; }

        public LogAttribute(string className)
        {
            ClassName = className;
        }
    }
}
