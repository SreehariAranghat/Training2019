﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DelegatesTraining
{
    public delegate void PostRegistrationTasks(Employee employeee);

    class Program
    {
      
        static void Main(string[] args)
        {
            Employee employee     = new Employee();
            Console.Write("Enter Employee Type");
            employee.EmployeeType = int.Parse(Console.ReadLine());
            employee.Name         = "Sree";

            PostRegistrationTasks postRegistrationTasks = new PostRegistrationTasks(SentJoiningKit);

            if (employee.EmployeeType == 1)
                postRegistrationTasks += ScheduleTraining;
            else
                postRegistrationTasks += SentProjectDetails;

            EmployeeRegistration.RegisterEmploee(employee, postRegistrationTasks);


        }

        static void ScheduleTraining(Employee employee)
        {
            Console.WriteLine($"Scheduling Training For Employee {employee.Id}");
            Console.WriteLine($"Sending training calender for employee {employee.Id}");
        }

        static void SentJoiningKit(Employee employee)
        {
            Console.WriteLine($"Sending joining kit to employee {employee.Id}");
        }

        static void SentProjectDetails(Employee employee)
        {
            Console.WriteLine($"Project details and location to {employee.Id}");
        }
    }

    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int EmployeeType { get; set; }
    }

    public class EmployeeRegistration
    {
        public static void RegisterEmploee(Employee employee,PostRegistrationTasks tasks)
        {
            employee.Id = new Random().Next();
            Console.WriteLine("Employee Registration Completed");
            tasks(employee);
        }
    }
}
