﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiDelegate
{
    class Program
    {
        delegate int ExecuteMultiple();
        static void Main(string[] args)
        {
            Func<int> func = Execute1;
            func += Execute2;

            foreach(Func<int> f in func.GetInvocationList())
            {
                int retValue = f();
                Console.WriteLine(retValue);
            }
        }

        public static int Execute1()
        {
            return 10;
        }

        public static int Execute2()
        {
            return 30;
        }
    }
}
