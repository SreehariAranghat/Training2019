﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAndEvents
{
    public class Account
    {
        public event EventHandler<AccountChangedEventArgs> AccountChanged;

        public void WithDraw(int amount)
        {
            AccountChanged(this, new AccountChangedEventArgs { AccountNumber = "1111", Amount = "100", Change = amount.ToString() });
        }
    }
}
