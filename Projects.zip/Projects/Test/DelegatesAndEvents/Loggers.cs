﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAndEvents
{
    public class FileLogger
    {
        public void Log(string message)
        {
            Console.WriteLine($@"File : c:\temp\log.txt, Log : {message} , Date : {DateTime.Now}");
        }
    }

    public class ConsoleLogger
    {
        public void Log(string message)
        {
            Console.WriteLine("Console : " + message);
        }
    }
}
