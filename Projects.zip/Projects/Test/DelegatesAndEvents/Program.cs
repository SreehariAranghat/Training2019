﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace DelegatesAndEvents
{
    class Program
    {
        public delegate void LogHandler(string message);
        public static event LogHandler LogEvent;



        static LogHandler logHandler = new LogHandler(new FileLogger().Log);

        static Timer timer = new Timer();

        static void Main(string[] args)
        {
            //timer.Elapsed += Timer_Elapsed;
            //timer.Start();


            //logHandler            += new ConsoleLogger().Log;
            //logHandler += (message) => { Console.WriteLine("Tick Event Occured"); };

            //LogEvent += Program_LogEvent;

            Account account = new Account();
            account.AccountChanged += Account_AccountChanged;

           
            account.WithDraw(1000);
            Console.WriteLine("With drawn");

            Console.ReadLine();
        }

        private static void Account_AccountChanged(object sender, AccountChangedEventArgs e)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Account amount changed {e.Amount}");
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            LogEvent("Clock ticketd");
        }

        private static void Program_LogEvent(string message)
        {
            logHandler(message);
        }
    }
}
