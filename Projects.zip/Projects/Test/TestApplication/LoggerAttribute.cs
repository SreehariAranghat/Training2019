﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    [AttributeUsage(AttributeTargets.Class)]
    public class LoggerAttribute : Attribute
    {
        public string User { get; set; }
        
        public LoggerAttribute(string className)
        {
            Console.WriteLine($"Class { className } was created at {DateTime.Now}");
        }
    }
}
