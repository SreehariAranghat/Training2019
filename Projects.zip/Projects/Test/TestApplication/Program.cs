﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Account acc1 = new Account { AccNo = 10, AccBalance = 100 };
            Account acc2 = new Account { AccNo = 20, AccBalance = 200 };

            Account account = acc1 + acc2;


            System.Reflection.MemberInfo memberInfo = typeof(Account);
            object[] attributes = memberInfo.GetCustomAttributes(true);

            foreach(Attribute att in attributes)
            {
                LoggerAttribute l = (LoggerAttribute)att;
                Console.WriteLine(l.User);

            }
        }
    }
}
