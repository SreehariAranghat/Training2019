﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication
{
    [Logger("ACcount",User = "Sree")]
    public class Account
    {
        public int AccNo { get; set; }
        public int AccBalance { get; set; }

        public static Account operator +(Account acc1, Account acc2)
        {
            return new Account { AccNo = acc1.AccNo, AccBalance = acc1.AccBalance + acc2.AccBalance };
        }
    }
}
