﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    public class Employee : INotifyPropertyChanged
    {
        string name = string.Empty;
        int basicSalary = 0;
        int overTime = 0;
        int travelAllowance = 0;

        public int TotalSalary { get {
                return basicSalary + overTime + travelAllowance;
            } }

        public string Name { get => name; set => name = value; }
        public int BasicSalary { get => basicSalary; set{ basicSalary = value; ChangedProperty("TotalSalary"); } }
        public int OverTime { get => overTime; set{ overTime = value; ChangedProperty("TotalSalary"); } }
        public int TravelAllowance { get => travelAllowance;
            set => travelAllowance = value; }

        public event PropertyChangedEventHandler PropertyChanged;

        public void ChangedProperty(string propertyName)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
