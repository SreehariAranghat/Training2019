﻿using GenericInterfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace GenericInterfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            Email email = new Email { To = "sreehariis@gmail.com"
                        , MessageContent = "Sample MEssage"
                        , Subject = "Email Subject" };

            SMS sms = new SMS { MessageContent = "HEllo There "
                            , MobileNumber = "233456666" };

            var emailService = ServiceSelector.Create<Email>(emai);

            PushNotification pushNotification 
                = new PushNotification { MobileNumber = "435645645"
                                                , MessageContent = "Hello There" };

            ISentService sentService = new SentService();
            sentService.Sent<Email>(email);
            sentService.Sent<SMS>(sms);
            sentService.Sent<PushNotification>(pushNotification);

            sentService.Sent<WatsappMessage>(new WatsappMessage
            { MessageContent = "TEst", WatsappNumber = "2354325$" });
            

        }
    }
}
