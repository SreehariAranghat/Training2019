﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterfaces.Services
{
    public class ServiceSelector
    {
        public static IMessageService<T> Create<T>(T t)
        {
            if(t is Email)
            {
                return new EmailService();
            }

            if(t is SMS)
            {
                return new SMSService();
            }


        }
    }
}
