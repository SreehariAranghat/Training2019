﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterfaces
{
    public class EmailService : IMessageService<Email>
    {
        public void Sent(Email t)
        {
            Console.WriteLine($"Sent Email To : {t.To}");
        }
    }
}
