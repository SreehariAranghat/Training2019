﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterfaces
{
    public class SMSService : IMessageService<SMS>
    {
        public void Sent(SMS t)
        {
            Console.WriteLine($"Sending SMS TO : {t.MobileNumber}");
        }
    }
}
