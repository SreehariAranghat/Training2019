﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterfaces
{
    public interface IMessageService<T> where T : Message
    {
        void Sent(T t);
    }
}
