﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterfaces
{
    public class SentService : ISentService
    {
        public void Sent<T>(T t) where T : Message
        {
            if(t is Email)
            {
                Email e = t as Email;
                Console.WriteLine($"Sending Email To:{e.To}, " +
                    $"Subject : {e.Subject}, Body : {e.MessageContent}");
                Console.WriteLine("Log Email Message");
            }

            if(t is SMS)
            {
                SMS s = t as SMS;
                Console.WriteLine("Sending SMS TO : {0}, Message {1}"
                        , s.MobileNumber, s.MessageContent);

                Console.WriteLine($"SENDING SMS TO: {s.MobileNumber} " +
                    $", SMS : {s.MessageContent}");
            }

            if(t is PushNotification)
            {
                PushNotification p = t as PushNotification;
                Console.WriteLine($"SENDING Push Notification " +
                    $"TO: {p.MobileNumber} , SMS : {p.MessageContent}");
            }
        }
    }
}
