﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterfaces
{
    abstract public class Message
    {
        public int MessageId { get; set; }
        public string MessageContent { get; set; }
    }

    public class SMS : Message
    {
        public string MobileNumber { get; set; }
    }

    public class Email : Message
    {
        public string To  { get; set; }
        public string Bcc { get; set; }
        public string CC  { get; set; }
        public string Subject { get; set; }
    }

    public class PushNotification : Message
    {
        public string MobileNumber { get; set; }
    }

    public class WatsappMessage : Message
    {
        public string WatsappNumber { get; set; }
    }
}
