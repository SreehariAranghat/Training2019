﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericInterfaces
{
    public interface ISentService
    {
        void Sent<T>(T t) where T : Message;
    }
}
