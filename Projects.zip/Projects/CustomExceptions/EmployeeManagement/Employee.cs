﻿using EmployeeManagement.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class Employee
    {
        [Range(1,1000,ErrorMessage = "Id Must be between 1 and 1000")]
        public int Id { get; set; }

        [Required]
        [StringLength(100,MinimumLength = 3
          ,ErrorMessage = "Name must be between 2- 100 characters")]
        [RegularExpression(@"^[a-zA-Z]+$",ErrorMessage = "Only alphabets are allowed for name")]
        public string Name { get; set; }

        [Required]
        public string Email { get; set; }

        public void Save()
        {
            List<ValidationResult> validationResults = new List<ValidationResult>();
            var isValid =  Validator.TryValidateObject(this, 
                new ValidationContext(this,null,null), validationResults);

            if (!isValid)
                throw new Exceptions.ValidationException("Validation Failed", validationResults);


        }
    }
}
