﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Exceptions
{
    public class ValidationException : ApplicationException
    {
        public ValidationException()
        {
        }

        public ValidationException(string message) : base(message)
        {
        }

        public ValidationException(string message, Exception innerException) : base(message, innerException)
        {
        }

        List<ValidationResult> validationResults = new List<ValidationResult>();

        public ValidationException(string message,List<ValidationResult> results)
            : base(message)
        {
            validationResults = results;
        }

        public override string ToString()
        {
            Console.WriteLine("Validation Errors");
            foreach (ValidationResult r in validationResults)
            {
                Console.WriteLine(r.MemberNames + ": " + r.ErrorMessage);
            }

            return base.ToString();
        }
    }
}
