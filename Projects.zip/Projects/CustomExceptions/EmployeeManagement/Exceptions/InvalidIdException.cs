﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Exceptions
{
    public class InvalidIdException : ApplicationException
    {
        string helpLinke = "http://docs.myapp.com/error/10001";

        public InvalidIdException() : base() {
            base.HelpLink = helpLinke;
        }
        public InvalidIdException(string message)
                : base(message) {
            base.HelpLink = helpLinke;
        }
        public InvalidIdException(string message
                        , Exception innerExceptions)
        {
            base.HelpLink = helpLinke;
        }

        public InvalidIdException(string message,int idProvided)
            : base(message + " Id Given was " + idProvided)
        {
            base.HelpLink = helpLinke;
        }

        public override string ToString()
        {
            string message = $"Opps,Something went wrong" +
                             $",Error : {this.Message}" +
                             $",For more information please visit {this.HelpLink}";

            return message;
        }
    }
}
