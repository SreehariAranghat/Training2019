﻿using EmployeeManagement;
using EmployeeManagement.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee employee = new Employee();
               
                employee.Save();
            }
            catch(ValidationException validationException)
            {
                Console.WriteLine(validationException.ValidationResult.ErrorMessage);
            }
            catch(InvalidIdException invalidIdException)
            {
                Console.WriteLine(invalidIdException.ToString());
            }
            catch(Exception excp)
            {
                throw;
            }
            finally
            {
                Console.WriteLine("Finally always runs");
            }

        }
    }
}
