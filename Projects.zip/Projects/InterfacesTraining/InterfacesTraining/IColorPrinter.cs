﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesTraining
{
    public interface IColorPrinter
    {
        void PrintInColor(string data, string font, string size, string color);
    }
}
