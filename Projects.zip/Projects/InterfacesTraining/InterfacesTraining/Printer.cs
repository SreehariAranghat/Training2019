﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesTraining
{
    public abstract class Printer
    {
        public string Name { get; set; }
        public string Manufacturer { get; set; }
        public string SerialNo { get; set; }

        protected string Data { get; set; }

        public void RecieveData(string data)
        {
            this.Data = data;
        }

        public abstract void Print(string data,string font,int fontsize);
    }
}
