﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            BlacknWhitePrinter printer = new BlacknWhitePrinter();
            printer.Print("Hello There","Arial",2);

            Console.Write("Enter the data :");
            string data = Console.ReadLine();

            Console.WriteLine("Select Printer 1=Color,2=Multifinction Color");
            int printerType = int.Parse(Console.ReadLine());

            IColorPrinter p = PrinterFactory.CreatePrinter(printerType);

           

            PrintSomeData(data, p);

        }

        public static void PrintSomeData(string data,IColorPrinter colorPrinter)
        {
            colorPrinter.PrintInColor(data, "Arial", "4", "Red");
        }
    }
}
