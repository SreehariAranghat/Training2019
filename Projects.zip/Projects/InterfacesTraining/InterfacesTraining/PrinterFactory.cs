﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesTraining
{
    public class PrinterFactory
    {
        public static IColorPrinter CreatePrinter(int printerType)
        {
            IColorPrinter p = null;

            if (printerType == 1)
                p = new ColorPrinter();
            else if (printerType == 2)
                p = new MultifunctionColorPrinter();
            else
                p = new LaserColorPrinter();

            return p;

        }
    }
}
