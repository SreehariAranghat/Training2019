﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesTraining
{
    public class BlacknWhitePrinter : Printer
    {
        public override void Print(string data, string font, int fontsize)
        {
            Console.WriteLine("Printing {0}, in font {1}, size{2}", data, font, fontsize);
            Console.WriteLine(data);
        }
    }

    public class ColorPrinter : Printer,IColorPrinter
    {
        public override void Print(string data, string font, int fontsize)
        {
            Console.WriteLine("Printing {0}, in font {1}, size{2}", data, font, fontsize);
            Console.WriteLine(data);
        }

        public void PrintInColor(string data, string font, string size, string color)
        {
            Console.WriteLine("Printing {0}, in font {1}, size{2}, in color {3}", data, font, size,color);
            Console.WriteLine(data);
        }
    }

    public class MultifunctionColorPrinter : Printer,IColorPrinter,IScanner
    {
        public override void Print(string data, string font, int fontsize)
        {
            Console.WriteLine("Printing {0}, in font {1}, size{2}", data, font, fontsize);
            Console.WriteLine(data);
        }

        public void PrintInColor(string data, string font, string size, string color)
        {
            Console.WriteLine("Printing {0}, in font {1}, size{2}, in color {3}", data, font, size, color);
            Console.WriteLine(data);
        }

        public string Scan()
        {
            string scandata = "@$DSSDDSD###############";
            Console.WriteLine("Sending Scan data " + scandata);
            return scandata;
        }
    }

    public class LaserColorPrinter : IColorPrinter
    {
        public void PrintInColor(string data, string font, string size, string color)
        {
            Console.WriteLine("Laster printing in color");
        }
    }
}
