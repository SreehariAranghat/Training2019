﻿
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace InteropText
{
    class Program
    {

        [DllImport("user32.dll")]
        public static extern int MessageBox(IntPtr hWnd
            , String text, String caption
            , int options);

        static void Main(string[] args)
        {
            BankAccount account = new BankAccount(1000, 2000);
            BankAccount account2 = new BankAccount(1000, 30000);

            BankAccount consolidatedAccount = account + account2;
            
        }

        public class BankAccount
        {
            public int CustomerId { get; set; }
            public int TotalAmount { get; set; }

            public BankAccount(int customerId, int totalAmount)
            {
                CustomerId = customerId;
                TotalAmount = totalAmount;
            }

            public static BankAccount operator +(BankAccount firstAccount,BankAccount secondAccount)
            {
                BankAccount account = firstAccount;
                account.TotalAmount += secondAccount.TotalAmount;

                return account;

            }

        }

        
    }
}
