﻿using System;
using System.Diagnostics;

namespace InteropText
{
    public  class ConsoleTraceListner : TraceListener
    {
        public ConsoleTraceListner()
        {
        }

        public override void Write(string message)
        {
            Console.WriteLine(message);
        }

        public override void WriteLine(string message)
        {
            Console.WriteLine(message);

        }
    }
}