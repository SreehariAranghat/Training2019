﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InteropText
{
    public partial class MathLibrary
    {
        public string LibraryName { get; set; }
        public string LibraryVersion { get; set; }

        partial void Subtract(int x,int y)
        {
            Console.WriteLine(x - y);
        }
    }
}
