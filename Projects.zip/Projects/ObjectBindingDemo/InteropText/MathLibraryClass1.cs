﻿#define VERSION_1_0

using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace InteropText
{
    public partial class MathLibrary
    {

       partial void Subtract(int x, int y);

        #region AddMethod
        public int Add(dynamic x,int y)
        {

            #if (VERSION_1_0)
     
                #warning The Method Add(int,int) is obselete please use Add(long,long)
            #endif
            return x + y;
        }

        public long Add(long x,long y)
        {
            Contract.Requires(x > y, "Invalid parameters password");
            return x + y;
        }
        #endregion
    }
}
