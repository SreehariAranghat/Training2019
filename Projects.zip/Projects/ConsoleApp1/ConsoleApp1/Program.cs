﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string conStr = ConfigurationManager.ConnectionStrings["defaultConnection"].ConnectionString;

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("INSERT INTO Employees(Name,CreatedDate)" +
                    " Values(@Name,@CreatedDate)",con);
                cmd.Parameters.AddWithValue("@Name", "Sree");
                cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);

                cmd.ExecuteNonQuery();

                SqlCommand getEmployeeCount = new SqlCommand("SELECT COUNT(*) FROM Employees",con);
                int totalEmployees = (int)getEmployeeCount.ExecuteScalar();

                Console.WriteLine("Total Employees = " + totalEmployees);

                SqlCommand getEmployeeList = new SqlCommand("SELECT * FROM Employees WHERE EmployeeId=1", con);
                SqlDataAdapter adapter = new SqlDataAdapter(getEmployeeList);
                DataTable employeeList = new DataTable("Employees");
               

                adapter.Fill(employeeList);

                foreach(DataRow row in employeeList.Rows)
                {
                    Console.WriteLine($"NAme : {row["Name"]} / EmployeeId : {row["EmployeeId"]}");
                }
            }
        }
    }
}
