﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqTraining
{
    class Program
    {
        static List<Employee> employees = new List<Employee>();
        static void Main(string[] args)
        {
            employees.Add(new Employee(1001, "Sree", 50000
                                        ,new Address { AddressText="NYC", PinCode = 50064 }));
            employees.Add(new Employee(1002, "Stark", 40000
                                        , new Address { AddressText = "NYC", PinCode = 50064 }));
            employees.Add(new Employee(1003, "Bill", 90000
                            , new Address { AddressText = "NYC", PinCode = 50094 }));

            var empList = employees.Where(d => d.Salary > 5000 
                                          && d.Name.IndexOf("S") == 0);

            var firstEmployeeWithS = empList.First(d => d.Name.IndexOf("S") == 0);

            var employeesFromCode64 = empList.Where(d => d.Address.PinCode == 50064);

            var employeeNames = empList.Where(d => d.Name.IndexOf("S") == 0)
                                    .Select(d => new { EmployeeName = d.Name, Salary = d.Salary });

            var distinctPinCode = employees.Select(d => d.Address.PinCode).Distinct();

            foreach (var e in employeeNames)
                Console.WriteLine(e.EmployeeName + " : " + e.Salary);
        }

        public class Employee
        {
            public int EmployeeId { get; set; }
            public string Name { get; set; }
            public int Salary { get; set; }

            public Address Address { get; set; }

            public Employee(int employeeId, string name, int salary,Address address)
            {
                EmployeeId = employeeId;
                Name = name;
                Salary = salary;
                Address = address;
            }

            public override string ToString()
            {
                return $"Id:{EmployeeId},Name : {Name} / Salary : {Salary}";
            }
        }

        public class Address
        {
            public string AddressText { get; set; }
            public int PinCode { get; set; }
        }
    }
}
