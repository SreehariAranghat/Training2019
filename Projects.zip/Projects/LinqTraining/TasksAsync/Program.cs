﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TasksAsync
{
    class Program
    {
        static CancellationTokenSource source = new CancellationTokenSource();

        static void Main(string[] args)
        {
            ProcessAllTasks();
            Counter2();
            Console.ReadLine();
        }

        public static async void ProcessAllTasks()
        {
            var result = await Counter1(source.Token);
            if(result > 0)
            {
                Console.WriteLine("Task Completed : " + result);
            }
        }

        public static async Task PrintSomeTask()
        {
            await Task.Run(() =>
            {
                Console.WriteLine("Post process task");
            });
        }
        public static async Task<int> Counter1(CancellationToken cancellationToken)
        {
            int counter = 0;
            await Task.Run(() => {

                
                for (int i = 0; i < 100; i++)
                {
                    if (!cancellationToken.IsCancellationRequested)
                    {
                        Console.WriteLine("Counter 1 :" + i);
                        counter += i;
                    }
                    else
                    {
                        Console.WriteLine("Cancelling Task at " + i);
                        break;
                    }
                }                
            });

            return counter;
        }

       public static void Counter2()
        {
            for(int i=0;i<100;i++)
            {
                Console.WriteLine("Counter 2 : " + i);

                if( i== 50)
                {
                    source.Cancel();
                    Console.WriteLine("Cancelling task 1");
                }
            }
        }
    }
}
