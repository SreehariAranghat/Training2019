﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequireInterfaces
{
    public static class EmployeeExtentions
    {
        public static string GenerateFullName(this Employee employee)
        {
            return "Dr." + employee.Name.ToUpper();
        }
    }
}
