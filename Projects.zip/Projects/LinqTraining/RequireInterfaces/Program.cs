﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RequireInterfaces
{
    class Program
    {
        static SortedSet<Employee> employees = new SortedSet<Employee>();
        static void Main(string[] args)
        {
            employees.Add(new Employee(10001, "Sree"));
            employees.Add(new Employee(10003, "Bill"));
            employees.Add(new Employee(10002, "Steve"));

            Employee employee = new Employee(10001, "Stark");
            employee.GenerateFullName();

            if (!employees.Contains(employee))
                employees.Add(employee);
            else
                Console.WriteLine("Employee already exist in the system");


            employee.CalculateSalary( bonus : 10, basicSalary: 100);
        }
 
    }

    public class Employee : IEquatable<Employee>
                        , IComparer<Employee>
            , IComparable<Employee>
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }

        public int CalculateSalary(int basicSalary,int bonus,int overTime = 0)
        {
            int salary = basicSalary + bonus + overTime;
            int tax = 100;

            return salary;
        }


       


        public Employee(int employeeId, string name)
        {
            EmployeeId = employeeId;
            Name = name;
        }

        public bool Equals(Employee other)
        {
            return this.EmployeeId == other.EmployeeId;
        }

        public int Compare(Employee x, Employee y)
        {
            if (x.EmployeeId > y.EmployeeId)
                return 1;
            if (x.EmployeeId < y.EmployeeId)
                return -1;
            else
                return 0;
        }

        public int CompareTo(Employee other)
        {
            if (this.EmployeeId > other.EmployeeId)
                return 1;
            if (this.EmployeeId < other.EmployeeId)
                return -1;
            else
                return 0;
        }
    }
}
