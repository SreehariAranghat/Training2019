using System;

public class Program
{
	public static void Main()
	{
		Console.WriteLine("Hello World !!!");
		Console.ReadLine();
	}
}