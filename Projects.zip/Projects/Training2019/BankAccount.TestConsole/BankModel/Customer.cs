﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankModel
{
    public abstract class Customer
    {
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public int AccountBalance { get; protected set; }
        public int WithDrawLimit  { get; protected set; }

        protected Customer(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName  = lastName;
        }

        public void Deposit(int amount)
        {
            AccountBalance += amount;
        }

        public void WithDraw(int amount)
        {
            if (amount <= AccountBalance)
                AccountBalance -= amount;
        }
    }

    public class RegularCustomer : Customer
    {
        public RegularCustomer(string firstname,string lastname) 
            : base(firstname,lastname)
        {
            base.WithDrawLimit = 20000;
        }
    }

    public class GoldCustomer : Customer
    {
        public GoldCustomer(string firstname,string lastname) : base(firstname,lastname)
        {
            base.WithDrawLimit = 50000;
        }
    }
}
