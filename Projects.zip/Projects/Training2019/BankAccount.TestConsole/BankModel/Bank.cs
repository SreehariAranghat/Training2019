﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace BankModel
{
    public class Bank : IDisposable
    {
        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                string namePattern = @"^[a-zA-Z]*";
                if (Regex.IsMatch(value, namePattern))
                    name = value;
                else
                    throw new Exception("Invalid Name");
            }
        }

        public string IfscCode { get => ifscCode
                        ; set {

                string ifscPattern = @"^[0-9a-zA-Z]*";
                if (Regex.IsMatch(value, ifscPattern) && value.Length == 4)
                    name = value;
                else
                    throw new Exception("Invalid IfSc Code");
            } }

        public Address Address { get; set; }

        public string Motto {
            get;
            private set;
        }
        private string ifscCode;


        Dictionary<int,Customer> customers 
            = new Dictionary<int, Customer>();


        public Bank()
        {

            this.Motto = "Customer First Bank";  
        }

        public void Dispose()
        {
            //Write custom code
        }

        public Customer AddCustomer(Customer customer)
        {
            customer.CustomerId = this.customers.Count + 1;
            this.customers.Add(customer.CustomerId,customer);
            return customer;
        }

        public Customer this[int id]
        {
            get { return customers[id]; }
        }

        public Customer this[string name]
        {
            get {
                    Customer c = null;
                    foreach(Customer customer in customers.Values)
                    {
                            if(customer.FirstName == name)
                            {
                                c = customer;
                                break;
                            }
                    }

                    return c;
            }
        }
    }
}
