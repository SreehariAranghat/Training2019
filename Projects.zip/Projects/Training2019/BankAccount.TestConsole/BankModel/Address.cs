﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankModel
{
    public class Address
    {
        public string AddressText { get; set; }
        public string State { get; set; }
        public string PinCode { get; set; }

        public Address(string addressText, string state, string pinCode)
        {
            AddressText = addressText;
            State = state;
            PinCode = pinCode;
        }
    }
}
