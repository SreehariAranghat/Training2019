﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BankModel;

namespace BankAccount.TestConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Address address = new Address("09,3r Street,NYC", "NYC", "560093");
            Bank bank = new Bank { Name = "Test Bank"
                                , IfscCode = "ICICI0001"
                                , Address = address };
            

            Customer regularCustomer = new RegularCustomer("Sreehari","ARnghat");
            Customer goldCustomer    = new GoldCustomer("Tony","Stark");


            bank.AddCustomer(regularCustomer);
            bank.AddCustomer(goldCustomer);


            Customer cu1  = bank[1];
            Customer cus2 = bank["Sreehari"];
          
        }
    }
}
