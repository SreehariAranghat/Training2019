﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassByRef
{
    class Program
    {
        static void Main(string[] args)
        {
            int original = 10;
            int increment = 30;

            AddNumber(out original, ref increment);

            Console.WriteLine("Original in main " + original);

            int age = 0;
            IsAgeEligible(ref age);

            NParams(1);
            NParams(1, 3, 4);
            NParams(1, "Sree", 1.3, "Hello");

        }

        static void NParams(params object [] paramlist)
        {
            Console.WriteLine("---------------------------");
            foreach(object o in paramlist)
            {
                Console.WriteLine(o.ToString());
            }
        }

        static void AddNumber(out int original,ref int increment)
        {
            original = 10;
            original =  increment;
            Console.WriteLine("Original " + original);
        }

        static void IsAgeEligible(ref int age)
        {
            string ageStr = Console.ReadLine();

            int tempAge;
            if (int.TryParse(ageStr, out tempAge))
                age = tempAge;
            else
                Console.WriteLine("Invalid Age");


            //age = int.Parse(Console.ReadLine());


            if (age > 18)
                Console.WriteLine("Some functuon");
            else
                Console.WriteLine("Another function");
        }
    }
}
