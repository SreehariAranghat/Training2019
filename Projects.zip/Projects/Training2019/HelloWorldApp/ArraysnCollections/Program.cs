﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysnCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrayList = new ArrayList();
            List<int> intArray = new List<int>();
            List<string> strArry = new List<string>();
            strArry.Add("Test 1");
            strArry.Add("TEst 2");

            Dictionary<int, string> studentList = new Dictionary<int, string>();
            studentList.Add(1, "Sree");
            studentList.Add(2, "Bill");
            studentList.Add(3, "Tom");

            SortedDictionary<int, string> sortStudents = new SortedDictionary<int, string>();
            sortStudents.Add(3, "Will");
            sortStudents.Add(1, "Tony");

            string studentNAme = studentList[1];

            Stack<string> stack = new Stack<string>();
            stack.Push("Item 1");
            stack.Push("Item 2");
            stack.Push("Item 3");

            string lastITem = stack.Pop();

            Queue<string> queue = new Queue<string>();


            intArray.Add(10);
            //intArray.Add("Sree");

            arrayList.Add(10);
            arrayList.Add(20);
            arrayList.Add(40);
            arrayList.Add("NYC");
            arrayList.Add(1.5F);

            arrayList.Insert(1, 30);
            //arrayList.Sort();

            int firstItem = (int)arrayList[0];

            foreach(object o in arrayList)
            {
                Console.WriteLine(o.ToString());
            }

            Console.WriteLine("Location of 30 is " + arrayList.IndexOf(30));


            Hashtable hashtable = new Hashtable();
            hashtable.Add("Karnataka", "Bangalore");
            hashtable.Add("Tamilnadu", "Chennei");
            hashtable.Add("Kerala", "TVM");

            Console.WriteLine("Capital of KA is " 
                    + hashtable["Karnataka"]);

           foreach(object state in hashtable.Keys)
            {
                Console.WriteLine(state);
            }
        }
    }
}
