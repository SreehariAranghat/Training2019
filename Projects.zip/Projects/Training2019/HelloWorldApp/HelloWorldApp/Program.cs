﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using  at = attris.com.MathLibrary;
using  lt   = lnt.com.MathLibray;

//using MathLibrary;

namespace HelloWorldApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;
            int y = 10;


            at.MathFunctions mf = new at.MathFunctions();
            lt.MathFunctions mf1 = new lt.MathFunctions();

            Console.WriteLine("Add" + mf.Add(x, y));
            Console.WriteLine("Subtract " + mf.Subtract(x, y));

        }
    }
}
